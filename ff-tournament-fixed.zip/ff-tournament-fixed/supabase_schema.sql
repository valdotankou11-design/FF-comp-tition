-- ═══════════════════════════════════════════════════════
--  TOURNOI FREE FIRE — Script SQL Supabase
--  Colle ce script dans : Supabase → SQL Editor → Run
-- ═══════════════════════════════════════════════════════

-- 1. Table des tournois
CREATE TABLE IF NOT EXISTS tournaments (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  name              TEXT        NOT NULL,
  date              DATE,
  max_players       INT         NOT NULL DEFAULT 16,
  players_per_group INT         NOT NULL DEFAULT 4,
  prize_1           TEXT        NOT NULL DEFAULT '600 Diamants',
  prize_2           TEXT        NOT NULL DEFAULT '220 Diamants',
  prize_3           TEXT        NOT NULL DEFAULT '110 Diamants',
  status            TEXT        NOT NULL DEFAULT 'open'
                                CHECK (status IN ('open','in_progress','finished','archived')),
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2. Table des joueurs
CREATE TABLE IF NOT EXISTS players (
  id          UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  pseudo      TEXT        NOT NULL,
  ff_id       TEXT        NOT NULL UNIQUE,
  email       TEXT        NOT NULL UNIQUE,
  whatsapp    TEXT        NOT NULL,
  password    TEXT        NOT NULL,
  group_name  TEXT,
  score       INT         NOT NULL DEFAULT 0,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 3. Index pour les requêtes fréquentes
CREATE INDEX IF NOT EXISTS idx_players_email       ON players(email);
CREATE INDEX IF NOT EXISTS idx_players_ff_id       ON players(ff_id);
CREATE INDEX IF NOT EXISTS idx_players_group_name  ON players(group_name);
CREATE INDEX IF NOT EXISTS idx_players_score       ON players(score DESC);
CREATE INDEX IF NOT EXISTS idx_tournaments_status  ON tournaments(status);
CREATE INDEX IF NOT EXISTS idx_tournaments_created ON tournaments(created_at DESC);

-- 4. Désactiver RLS (le backend utilise la service_role key)
ALTER TABLE tournaments DISABLE ROW LEVEL SECURITY;
ALTER TABLE players     DISABLE ROW LEVEL SECURITY;

-- Verification
SELECT 'tournaments' as table_name, COUNT(*) as rows FROM tournaments
UNION ALL
SELECT 'players', COUNT(*) FROM players;
