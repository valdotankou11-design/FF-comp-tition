# 🔥 Tournoi Free Fire — Guide de déploiement complet

Stack : **Python (Flask) + Supabase (PostgreSQL) + Vercel**

---

## 📁 Structure du projet

```
ff-tournament/
├── api/
│   └── index.py          ← Application Flask + toute la logique
├── templates/
│   └── index.html        ← Interface thème Free Fire
├── requirements.txt      ← flask + supabase
├── vercel.json
└── README.md
```

---

## 🗄️ ÉTAPE 1 — Créer la base Supabase

### 1.1 Créer le projet

1. Va sur [supabase.com](https://supabase.com) → **New project**
2. Nom : `ff-tournament` | Région : choisir la plus proche (Europe West)
3. Définis un mot de passe de base de données fort → **Create project**
4. Attends ~2 minutes que le projet démarre

### 1.2 Créer les tables

Dans Supabase → **SQL Editor** → colle et exécute ce script :

```sql
-- Table des tournois
CREATE TABLE tournaments (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name              TEXT NOT NULL,
  date              DATE,
  max_players       INT  NOT NULL DEFAULT 16,
  players_per_group INT  NOT NULL DEFAULT 4,
  prize_1           TEXT DEFAULT '600 Diamants',
  prize_2           TEXT DEFAULT '220 Diamants',
  prize_3           TEXT DEFAULT '110 Diamants',
  status            TEXT NOT NULL DEFAULT 'open'
                    CHECK (status IN ('open','in_progress','finished','archived')),
  created_at        TIMESTAMPTZ DEFAULT NOW()
);

-- Table des joueurs
CREATE TABLE players (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  pseudo      TEXT NOT NULL,
  ff_id       TEXT NOT NULL UNIQUE,
  email       TEXT NOT NULL UNIQUE,
  whatsapp    TEXT NOT NULL,
  password    TEXT NOT NULL,
  group_name  TEXT,
  score       INT  DEFAULT 0,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- Index pour performances
CREATE INDEX idx_players_email      ON players(email);
CREATE INDEX idx_players_group_name ON players(group_name);
CREATE INDEX idx_tournaments_status ON tournaments(status);
```

### 1.3 Désactiver RLS (Row Level Security)

Le backend Flask utilise la **service key** → les règles RLS ne s'appliquent pas,
mais par sécurité désactive-les explicitement :

```sql
ALTER TABLE tournaments DISABLE ROW LEVEL SECURITY;
ALTER TABLE players     DISABLE ROW LEVEL SECURITY;
```

### 1.4 Récupérer les clés Supabase

Dans Supabase → **Settings → API** :
- **Project URL** → `SUPABASE_URL`
- **service_role key** (secret, pas anon) → `SUPABASE_KEY`

---

## 🚀 ÉTAPE 2 — Déployer sur Vercel

### 2.1 GitHub

```bash
git init
git add .
git commit -m "Tournoi Free Fire — Supabase"
# Créer un repo sur github.com puis :
git remote add origin https://github.com/TON-USER/ff-tournament.git
git push -u origin main
```

### 2.2 Importer sur Vercel

1. [vercel.com](https://vercel.com) → **Add New Project** → importe le repo
2. Framework Preset : **Other**
3. Clique **Deploy** (Vercel détecte Python automatiquement)

### 2.3 Variables d'environnement

**Vercel → Settings → Environment Variables** :

| Variable          | Valeur                          | Description                       |
|-------------------|---------------------------------|-----------------------------------|
| `SUPABASE_URL`    | `https://xxxx.supabase.co`      | URL de ton projet Supabase        |
| `SUPABASE_KEY`    | `eyJhbGci...` (service_role)    | Clé service Supabase              |
| `SECRET_KEY`      | chaîne aléatoire (32+ chars)    | Sécurité sessions Flask           |
| `ADMIN_PASSWORD`  | ton mot de passe admin          | Accès panneau admin               |
| `SMTP_HOST`       | `smtp.gmail.com`                | Serveur email                     |
| `SMTP_PORT`       | `587`                           | Port SMTP                         |
| `SMTP_USER`       | `ton.email@gmail.com`           | Adresse Gmail expéditrice         |
| `SMTP_PASS`       | `xxxx xxxx xxxx xxxx`           | Mot de passe d'application Gmail  |

Après ajout des variables → **Redeploy** (Settings → Deployments → Redeploy)

---

## 📧 ÉTAPE 3 — Configurer Gmail

1. [myaccount.google.com](https://myaccount.google.com) → **Sécurité**
2. Active la **Validation en 2 étapes** si pas déjà fait
3. Cherche **Mots de passe des applications**
4. Appli : "Autre" → tape `Tournoi FF` → **Générer**
5. Copie le code 16 caractères → colle dans `SMTP_PASS` sur Vercel

---

## 👑 Utilisation Admin

**Connexion :** email = `admin` | mot de passe = valeur de `ADMIN_PASSWORD`

**Actions disponibles :**
- ➕ Créer un tournoi (nom, date, places, joueurs/poule, prix)
- 🎲 Lancer le tirage au sort → répartition aléatoire + emails automatiques
- 📊 Saisir les scores joueur par joueur
- 👥 Voir et supprimer les joueurs inscrits

---

## 🎮 Parcours Joueur

1. S'inscrit : Pseudo FF, ID FF, Email, WhatsApp, Mot de passe
2. **Admin reçoit un email** à chaque inscription sur `valdo.soh@facsciences-uy1.com`
3. Après le tirage : **le joueur reçoit un email** avec son groupe + adversaires
4. Se connecte → voit sa poule en surbrillance, les scores en temps réel
5. À chaque mise à jour de score → **email de notification** au joueur

---

## 📊 Données dans Supabase

Tu peux voir toutes les données dans **Supabase → Table Editor** :
- `tournaments` → tous les tournois (actif + archivés)
- `players` → tous les joueurs avec leurs groupes et scores

