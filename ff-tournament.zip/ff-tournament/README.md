# 🔥 Tournoi Free Fire — Site de compétition

Site de gestion de tournoi Free Fire avec poules, comptes joueurs et notifications email.  
Stack : **100% Python (Flask)** — Déploiement sur **Vercel**

---

## 📁 Structure du projet

```
ff-tournament/
├── api/
│   └── index.py          ← Application Flask principale
├── templates/
│   └── index.html        ← Interface utilisateur (thème FF)
├── requirements.txt
├── vercel.json
└── README.md
```

---

## 🚀 Déploiement sur Vercel

### 1. Préparer le dépôt GitHub

```bash
git init
git add .
git commit -m "Tournoi Free Fire init"
# Crée un repo sur github.com puis :
git remote add origin https://github.com/TON-USER/ff-tournament.git
git push -u origin main
```

### 2. Importer sur Vercel

1. Va sur [vercel.com](https://vercel.com) → **Add New Project**
2. Importe ton repo GitHub
3. Vercel détecte automatiquement Python

### 3. Variables d'environnement (OBLIGATOIRE)

Dans Vercel → **Settings → Environment Variables**, ajoute :

| Variable | Valeur | Description |
|----------|--------|-------------|
| `SECRET_KEY` | (chaîne aléatoire) | Sécurité sessions Flask |
| `ADMIN_PASSWORD` | (ton mot de passe) | Mot de passe admin |
| `SMTP_HOST` | `smtp.gmail.com` | Serveur email |
| `SMTP_PORT` | `587` | Port SMTP |
| `SMTP_USER` | `ton.email@gmail.com` | Ton adresse Gmail |
| `SMTP_PASS` | `xxxx xxxx xxxx xxxx` | Mot de passe d'application Gmail |

### 4. Obtenir un mot de passe d'application Gmail

1. Va sur [myaccount.google.com](https://myaccount.google.com)
2. Sécurité → **Validation en deux étapes** (active-la si nécessaire)
3. Sécurité → **Mots de passe des applications**
4. Sélectionne "Autre" → tape "Tournoi FF" → Générer
5. Copie le code à 16 caractères → colle dans `SMTP_PASS`

---

## 👑 Compte administrateur

- **Email de connexion :** `admin`
- **Mot de passe :** Valeur de ta variable `ADMIN_PASSWORD`

En tant qu'admin tu peux :
- Créer un tournoi (nom, date, nb. places, nb. joueurs/poule, prix)
- Lancer le tirage au sort des poules (aléatoire)
- Saisir les scores des joueurs
- Voir la liste complète des inscrits
- Recevoir un email à chaque nouvelle inscription

---

## 🎮 Fonctionnement joueur

1. S'inscrit avec : Pseudo FF, ID FF, Email, WhatsApp, Mot de passe
2. Reçoit une confirmation → visible dans son espace
3. Après le tirage : reçoit un email avec son groupe et ses adversaires
4. Se connecte pour suivre sa poule et les scores en direct

---

## 📧 Emails automatiques

- **Admin (`valdo.soh@facsciences-uy1.com`)** → reçoit un email à chaque inscription
- **Joueur** → reçoit son groupe et la liste de ses adversaires après le tirage

---

## ⚠️ Note sur le stockage

Vercel utilise un filesystem éphémère (`/tmp`). Pour un tournoi en production,
remplace le stockage JSON par une base de données :
- **Vercel KV** (Redis) — gratuit jusqu'à 30k req/mois
- **Supabase** (PostgreSQL) — gratuit
- **MongoDB Atlas** — gratuit

Dis-moi si tu veux que je migre vers l'une de ces solutions !
