from flask import Flask, request, jsonify, session, render_template_string
import json, os, random, hashlib, smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime
import re

app = Flask(__name__, template_folder='../templates', static_folder='../static')
app.secret_key = os.environ.get('SECRET_KEY', 'ff-tournament-secret-2025')

DATA_FILE = '/tmp/tournament_data.json'
ADMIN_EMAIL = 'valdo.soh@facsciences-uy1.com'
ADMIN_PASSWORD = os.environ.get('ADMIN_PASSWORD', 'admin1234')

# ──────────────────── Data helpers ────────────────────

def load_data():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE) as f:
            return json.load(f)
    return {"tournament": None, "players": {}, "groups": {}}

def save_data(data):
    with open(DATA_FILE, 'w') as f:
        json.dump(data, f, indent=2)

def hash_password(pw):
    return hashlib.sha256(pw.encode()).hexdigest()

# ──────────────────── Email ────────────────────

def send_email(to_email, subject, html_body):
    smtp_host = os.environ.get('SMTP_HOST', 'smtp.gmail.com')
    smtp_port = int(os.environ.get('SMTP_PORT', 587))
    smtp_user = os.environ.get('SMTP_USER', '')
    smtp_pass = os.environ.get('SMTP_PASS', '')
    if not smtp_user:
        return False
    try:
        msg = MIMEMultipart('alternative')
        msg['Subject'] = subject
        msg['From'] = smtp_user
        msg['To'] = to_email
        msg.attach(MIMEText(html_body, 'html'))
        with smtplib.SMTP(smtp_host, smtp_port) as s:
            s.starttls()
            s.login(smtp_user, smtp_pass)
            s.sendmail(smtp_user, [to_email, ADMIN_EMAIL], msg.as_string())
        return True
    except Exception as e:
        print(f"Email error: {e}")
        return False

def notify_admin_registration(player):
    subject = f"🎮 Nouvelle inscription - {player['pseudo']}"
    html = f"""
    <div style="font-family:Arial;background:#111;color:#fff;padding:20px;border-radius:10px">
      <h2 style="color:#f5a623">🔥 Tournoi Free Fire — Nouvelle Inscription</h2>
      <table style="width:100%;border-collapse:collapse">
        <tr><td style="padding:8px;color:#aaa">Pseudo FF</td><td style="padding:8px;color:#f5a623;font-weight:bold">{player['pseudo']}</td></tr>
        <tr><td style="padding:8px;color:#aaa">ID Free Fire</td><td style="padding:8px">{player['ff_id']}</td></tr>
        <tr><td style="padding:8px;color:#aaa">Email</td><td style="padding:8px">{player['email']}</td></tr>
        <tr><td style="padding:8px;color:#aaa">WhatsApp</td><td style="padding:8px">{player['whatsapp']}</td></tr>
        <tr><td style="padding:8px;color:#aaa">Date</td><td style="padding:8px">{datetime.now().strftime('%d/%m/%Y %H:%M')}</td></tr>
      </table>
    </div>"""
    send_email(ADMIN_EMAIL, subject, html)

def notify_player_group(player, group_name, group_members):
    members_html = ''.join(f"<li style='padding:4px 0;color:#fff'>{m['pseudo']} <span style='color:#888'>({m['ff_id']})</span></li>" for m in group_members)
    subject = f"🏆 Tu es dans le {group_name} — Tournoi Free Fire"
    html = f"""
    <div style="font-family:Arial;background:#111;color:#fff;padding:20px;border-radius:10px;max-width:500px">
      <h2 style="color:#f5a623">🔥 TOURNOI FREE FIRE</h2>
      <p>Salut <strong style="color:#f5a623">{player['pseudo']}</strong> !</p>
      <p>Tu as été tiré au sort dans le <strong style="color:#fff">{group_name}</strong>.</p>
      <h3 style="color:#f5a623;border-bottom:1px solid #333;padding-bottom:8px">🎯 Tes adversaires</h3>
      <ul style="list-style:none;padding:0">{members_html}</ul>
      <p style="color:#aaa;font-size:12px;margin-top:20px">Connecte-toi sur le site pour suivre l'évolution du tournoi.</p>
    </div>"""
    send_email(player['email'], subject, html)

# ──────────────────── Routes ────────────────────

@app.route('/')
def index():
    return render_template_string(open(os.path.join(os.path.dirname(__file__), '../templates/index.html')).read())

# --- Auth ---
@app.route('/api/register', methods=['POST'])
def register():
    data = load_data()
    body = request.json
    pseudo = body.get('pseudo', '').strip()
    ff_id = body.get('ff_id', '').strip()
    email = body.get('email', '').strip().lower()
    whatsapp = body.get('whatsapp', '').strip()
    password = body.get('password', '')

    if not all([pseudo, ff_id, email, whatsapp, password]):
        return jsonify({'error': 'Tous les champs sont requis'}), 400
    if email in data['players']:
        return jsonify({'error': 'Email déjà utilisé'}), 400

    t = data.get('tournament')
    if t:
        registered = len(data['players'])
        if registered >= t['max_players']:
            return jsonify({'error': 'Le tournoi est complet !'}), 400

    player = {
        'pseudo': pseudo, 'ff_id': ff_id,
        'email': email, 'whatsapp': whatsapp,
        'password': hash_password(password),
        'registered_at': datetime.now().isoformat(),
        'group': None
    }
    data['players'][email] = player
    save_data(data)
    notify_admin_registration(player)
    session['user'] = email
    return jsonify({'success': True, 'player': {k: v for k, v in player.items() if k != 'password'}})

@app.route('/api/login', methods=['POST'])
def login():
    data = load_data()
    body = request.json
    email = body.get('email', '').strip().lower()
    password = body.get('password', '')
    if email == 'admin' and password == ADMIN_PASSWORD:
        session['user'] = 'admin'
        session['is_admin'] = True
        return jsonify({'success': True, 'is_admin': True})
    player = data['players'].get(email)
    if not player or player['password'] != hash_password(password):
        return jsonify({'error': 'Email ou mot de passe incorrect'}), 401
    session['user'] = email
    session['is_admin'] = False
    return jsonify({'success': True, 'is_admin': False, 'player': {k: v for k, v in player.items() if k != 'password'}})

@app.route('/api/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'success': True})

@app.route('/api/me')
def me():
    if 'user' not in session:
        return jsonify({'logged_in': False})
    if session.get('is_admin'):
        return jsonify({'logged_in': True, 'is_admin': True})
    data = load_data()
    player = data['players'].get(session['user'])
    if not player:
        return jsonify({'logged_in': False})
    return jsonify({'logged_in': True, 'is_admin': False, 'player': {k: v for k, v in player.items() if k != 'password'}})

# --- Tournament ---
@app.route('/api/tournament', methods=['GET'])
def get_tournament():
    data = load_data()
    t = data.get('tournament')
    players_count = len(data['players'])
    return jsonify({'tournament': t, 'players_count': players_count})

@app.route('/api/tournament', methods=['POST'])
def create_tournament():
    if not session.get('is_admin'):
        return jsonify({'error': 'Non autorisé'}), 403
    data = load_data()
    body = request.json
    data['tournament'] = {
        'name': body.get('name', 'Tournoi Free Fire'),
        'date': body.get('date', ''),
        'max_players': int(body.get('max_players', 16)),
        'players_per_group': int(body.get('players_per_group', 4)),
        'prize_1': body.get('prize_1', '600 Diamants'),
        'prize_2': body.get('prize_2', '220 Diamants'),
        'prize_3': body.get('prize_3', '110 Diamants'),
        'status': 'open',
        'created_at': datetime.now().isoformat()
    }
    data['groups'] = {}
    save_data(data)
    return jsonify({'success': True, 'tournament': data['tournament']})

@app.route('/api/tournament/draw', methods=['POST'])
def draw_groups():
    if not session.get('is_admin'):
        return jsonify({'error': 'Non autorisé'}), 403
    data = load_data()
    t = data.get('tournament')
    if not t:
        return jsonify({'error': 'Pas de tournoi'}), 400
    players = list(data['players'].values())
    random.shuffle(players)
    ppg = t['players_per_group']
    groups = {}
    group_letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    for i, player in enumerate(players):
        gi = i // ppg
        gname = f"Groupe {group_letters[gi]}"
        if gname not in groups:
            groups[gname] = {'members': [], 'scores': {}}
        groups[gname]['members'].append(player['email'])
        data['players'][player['email']]['group'] = gname
    data['groups'] = groups
    data['tournament']['status'] = 'in_progress'
    save_data(data)
    # Notify players
    for gname, g in groups.items():
        members_data = [data['players'][e] for e in g['members']]
        for p in members_data:
            notify_player_group(p, gname, members_data)
    return jsonify({'success': True, 'groups': groups})

@app.route('/api/groups', methods=['GET'])
def get_groups():
    data = load_data()
    groups = data.get('groups', {})
    result = {}
    for gname, g in groups.items():
        members = []
        for email in g['members']:
            p = data['players'].get(email, {})
            members.append({
                'pseudo': p.get('pseudo'), 'ff_id': p.get('ff_id'),
                'email': email,
                'score': g['scores'].get(email, 0)
            })
        members.sort(key=lambda x: x['score'], reverse=True)
        result[gname] = {'members': members}
    return jsonify({'groups': result})

@app.route('/api/score', methods=['POST'])
def set_score():
    if not session.get('is_admin'):
        return jsonify({'error': 'Non autorisé'}), 403
    data = load_data()
    body = request.json
    group = body.get('group')
    email = body.get('email')
    score = int(body.get('score', 0))
    if group not in data['groups']:
        return jsonify({'error': 'Groupe introuvable'}), 404
    data['groups'][group]['scores'][email] = score
    save_data(data)
    return jsonify({'success': True})

@app.route('/api/players', methods=['GET'])
def get_players():
    if not session.get('is_admin'):
        return jsonify({'error': 'Non autorisé'}), 403
    data = load_data()
    players = [{k: v for k, v in p.items() if k != 'password'} for p in data['players'].values()]
    return jsonify({'players': players})

if __name__ == '__main__':
    app.run(debug=True)
